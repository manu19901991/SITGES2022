/**
  ******************************************************************************
  * @file    Templates/TrustZoneDisabled/Src/main.c
  * @author  MCD Application Team
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/** @addtogroup STM32U5xx_HAL_Examples
  * @{
  */

/** @addtogroup Templates
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
//#define FREQUENCY_TEST
/* Private macro -------------------------------------------------------------*/

enum lpModeState {
	ENTER,
	EXIT
}state = ENTER;

//lpModeState state = ENTER;

/* Private variables ---------------------------------------------------------*/
uint16_t adc_data[ADC_BUFFER_CHECK_SIZE];
uint16_t adc_data_Buff1[ADC_BUFFER_SIZE_256];
uint16_t adc_data_Buff2[ADC_BUFFER_SIZE_64];

uint16_t dataPoint = 0;
uint32_t LPTIM_ARR ;
uint32_t LPTIM_CMP ;

ADC_HandleTypeDef ADCHandle;

DMA_HandleTypeDef DMAHandle1;

ADC_ChannelConfTypeDef   adc_sConfig;
RCC_PeriphCLKInitTypeDef  RCC_PeriphCLKInitStruct;
LPTIM_HandleTypeDef LPTIM_Handle; //  LPTIM1
__IO uint32_t UserButtonStatus = 0;  /* set to 1 after User Button interrupt  */

/* Private function prototypes -----------------------------------------------*/
static void SystemClock_Config_LP(void);
static void CACHE_Enable(void);
static void GPIO_Init(void);
void BSP_PB_Callback(Button_TypeDef Button);
void Error_Handler(void);
void DMA_init_LPTIM_Update(void);
void ADC_Init(void);
void LPTIM_Start(void);
void LPTIM_Init(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None-+
  * @retval None
  */
int main(void)
{
  /* STM32U5xx HAL library initialization  */
   HAL_Init();

  /* Enable Power Control clock */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_CLEAR_FLAG(PWR_WAKEUP_ALL_FLAG);

  /*Enable ultra low power mode*/
  HAL_PWREx_EnableUltraLowPowerMode();

  /*The SMPS regulator supplies the Vcore Power Domains.*/
  HAL_PWREx_ConfigSupply(PWR_SMPS_SUPPLY);

  /* Disable RAM page(s) content lost in Stop mode (Stop 0, 1, 2, 3) */
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM1_PAGE1_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM1_PAGE2_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM1_PAGE3_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM2_PAGE1_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM2_PAGE2_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE1_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE2_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE3_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE4_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE5_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE6_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE7_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_SRAM3_PAGE8_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_DMA2DRAM_FULL_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_PKA32RAM_FULL_STOP_RETENTION);
  HAL_PWREx_DisableRAMsContentStopRetention(PWR_PERIPHRAM_FULL_STOP_RETENTION);
  HAL_PWREx_EnableRAMsContentStopRetention(PWR_SRAM4_FULL_STOP_RETENTION);
  HAL_PWREx_EnableRAMsContentStopRetention(PWR_ICACHE_FULL_STOP_RETENTION);

  HAL_DBGMCU_DisableDBGStopMode();



  /* Enable the Intruction Cache */
  CACHE_Enable();

  /* Configure the System clock  */
  SystemClock_Config_LP();

  /* Configure pins*/
  GPIO_Init();
  /* Add your application code here*/

  /* ADC Init  */
  ADC_Init();

  /* LPTIM 1 CH1 Init */
  LPTIM_Init();

  /* Update LPTIM1_ARR */

#ifndef FREQUENCY_TEST
  LPTIM_ARR=512;
  LPTIM_CMP=250;
#endif
  /* Update LPTIM1_RCR */

#ifdef FREQUENCY_TEST
  LPTIM_ARR=51;
  LPTIM_CMP=25;
#endif
  /* Start Conversion */
  LPTIM_Start();

  /* Infinite loop */
  while (1)
  {
	  if(state == ENTER){
		  HAL_SuspendTick();
		  HAL_PWREx_EnterSTOP2Mode(PWR_STOPENTRY_WFI);
		  HAL_ResumeTick();
	  }
  }
}

/**
  * @brief  System Clock Configuration
  *         The system Clock is configured as follows :
  *            System Clock source            = PLL (MSI)
  *            SYSCLK(Hz)                     = 160000000
  *            HCLK(Hz)                       = 160000000
  *            AHB Prescaler                  = 1
  *            APB1 Prescaler                 = 1
  *            APB2 Prescaler                 = 1
  *            APB3 Prescaler                 = 1
  *            MSI Frequency(Hz)              = 4000000
  *            PLL_M                          = 1
  *            PLL_N                          = 80
  *            PLL_Q                          = 2
  *            PLL_R                          = 2
  *            PLL_P                          = 2
  *            Flash Latency(WS)              = 4
  * @param  None
  * @retval None
  */

void SystemClock_Config_LP(void)
{
   RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  /*Set VOLTAGE SCALE range 4 : Freq MAX 24 MHZ  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE4);

  /* SET MSIK clock RANGE */
  __HAL_RCC_MSIK_RANGE_CONFIG(RCC_MSIRANGE_4);
  /* Enable MSIK clock */
  __HAL_RCC_MSIK_ENABLE();
  /* Enable LSE clock */
  RCC_OscInitStruct.OscillatorType =  RCC_OSCILLATORTYPE_LSI | RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  RCC_OscInitStruct.LSEState = RCC_LSE_OFF;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /* Enable the Power-down Mode for Flash Banks*/
  HAL_FLASHEx_EnablePowerDown(FLASH_BANK_2);
  /* Configuration of the LPM read mode*/
  HAL_FLASHEx_ConfigLowPowerRead(FLASH_LPM_ENABLE);

}
/**
  * @brief  Enable I-Cache and D-Cache.
  * @param  None
  * @retval None
  */
static void CACHE_Enable(void)
{
  /* Icache in direct map */
  CLEAR_BIT(ICACHE->CR, ICACHE_CR_WAYSEL);
  /* Icache enable */
  SET_BIT(ICACHE->CR, ICACHE_CR_EN);
}


static void GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */


  /*Configure GPIO pins : PE2 PE3 PE4 PE5
                           PE6 PE7 PE8 PE9
                           PE10 PE11 PE12 PE13
                           PE14 PE15 PE0 PE1 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);



  /*Configure GPIO pins : PF0 PF1 PF2 PF3
                           PF4 PF5 PF6 PF7
                           PF8 PF9 PF10 PF11
                           PF12 PF13 PF14 PF15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : PH0 PH1 PH3 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 PC1 VBUS_SENSE_Pin PC3
                           PC6 PC7 PC8 PC9
                           PC10 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_3
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_9
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3
                           PA4 PA8 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_8|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = GPIO_PIN_5;
   GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

   /*Configure GPIO pin : PA6 */
   GPIO_InitStruct.Pin = GPIO_PIN_6;
   GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
   GPIO_InitStruct.Pull = GPIO_NOPULL;
   HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

   /*Configure GPIO pin : PA7 */
   GPIO_InitStruct.Pin = GPIO_PIN_7;
   GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
   GPIO_InitStruct.Pull = GPIO_NOPULL;

   HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);


  /*Configure GPIO pins : PB0 PB1 PB2 PB10
                           PB11 PB13 PB15 PB4
                           PB5 PB6 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10
                          |GPIO_PIN_11|GPIO_PIN_13|GPIO_PIN_15|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PG0 PG1 PG2 PG3
                           PG4 PG5 PG6 PG7
                           PG8 PG9 PG10 PG12
                           PG13 PG14 PG15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_12
                          |GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pin : UCPD_FLT_Pin */


  /*Configure GPIO pins : PD8 PD9 PD10 PD11
                           PD12 PD13 PD14 PD15
                           PD0 PD1 PD2 PD3
                           PD4 PD5 PD6 PD7 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15
                          |GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : PA11 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_BLUE_Pin */


}


void ADC_Init(void)
{
  /*Enable VDDA for ADC Conversion */
  HAL_PWREx_EnableVddA();
  /* Enable ADC clocks */
  __HAL_RCC_ADC4_CLK_ENABLE();

  /* Config ADC Handle */
  ADCHandle.Instance= ADC_INSTANCE;
  ADCHandle.Init.Resolution = ADC_RESOLUTION_12B;
  ADCHandle.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  ADCHandle.Init.NbrOfConversion = 1;
  ADCHandle.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  ADCHandle.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DR;
  ADCHandle.Init.OversamplingMode = DISABLE;
  ADCHandle.Init.LowPowerAutoWait = DISABLE;

  ADCHandle.Init.LowPowerAutoPowerOff = ENABLE;
  ADCHandle.Init.ExternalTrigConv = ADC_SOFTWARE_START;

  if(HAL_ADC_Init(&ADCHandle)!= HAL_OK)
  {
    Error_Handler();
  }

  /* Enable ADC4 Power Down */
  __ADC_EnableDeepPowerDown(&ADCHandle);

      /*Config ADC Channel*/
  adc_sConfig.Channel = ADC_CHANNEL;
  adc_sConfig.Rank = ADC4_RANK_CHANNEL_NUMBER;
  adc_sConfig.SamplingTime = LL_ADC4_SAMPLINGTIME_1CYCLE_5;
  adc_sConfig.SingleDiff = ADC_SINGLE_ENDED;
  adc_sConfig.OffsetNumber = ADC_OFFSET_NONE;
  if( HAL_ADC_ConfigChannel(&ADCHandle, &adc_sConfig)!= HAL_OK)
  {
    Error_Handler();
  }

}

void LPTIM_Init()
{
  /* Enable LP timer */
  __HAL_RCC_LPTIM1_CLK_ENABLE();

  RCC_PeriphCLKInitTypeDef  RCC_PeriphCLKInitStruct;
  LPTIM_OC_ConfigTypeDef sConfig;

  /* Set LSE as LPTIM1 Clock */
  RCC_PeriphCLKInitStruct.PeriphClockSelection = RCC_PERIPHCLK_LPTIM1;
  RCC_PeriphCLKInitStruct.Lptim1ClockSelection = RCC_LPTIM1CLKSOURCE_LSI;
  HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphCLKInitStruct);

  /* LPTIM init function - used for ADC_TRIG */
  LPTIM_Handle.Instance = LPTIM1;
  LPTIM_Handle.Init.CounterSource                 = LPTIM_COUNTERSOURCE_INTERNAL;
  LPTIM_Handle.Init.UpdateMode                    = LPTIM_UPDATE_IMMEDIATE;
  LPTIM_Handle.Init.Clock.Source                  = LPTIM_CLOCKSOURCE_APBCLOCK_LPOSC;
  LPTIM_Handle.Init.Clock.Prescaler               = LPTIM_PRESCALER_DIV1;
  LPTIM_Handle.Init.UltraLowPowerClock.Polarity   = LPTIM_CLOCKPOLARITY_RISING;
  LPTIM_Handle.Init.UltraLowPowerClock.SampleTime = LPTIM_CLOCKSAMPLETIME_DIRECTTRANSITION;
  LPTIM_Handle.Init.Trigger.Source                = LPTIM_TRIGSOURCE_SOFTWARE;

#ifndef FREQUENCY_TEST
  LPTIM_Handle.Init.Period                        = Period_256HZ-1 ;
#endif


#ifdef FREQUENCY_TEST
  LPTIM_Handle.Init.Period                        = 12;
#endif

  LPTIM_Handle.Init.RepetitionCounter             = 0 ;

  HAL_LPTIM_Init(&LPTIM_Handle);

  /* Configur Pulse and Polarity Channel */

#ifndef FREQUENCY_TEST
  sConfig.Pulse      = (Period_256HZ-1)/2;

#endif

#ifdef FREQUENCY_TEST

  sConfig.Pulse      = 6;

#endif
  sConfig.OCPolarity = LPTIM_OCPOLARITY_LOW;
  if(HAL_LPTIM_OC_ConfigChannel(&LPTIM_Handle, &sConfig, LPTIM_CHANNEL_1)!=HAL_OK)
  {
    Error_Handler();
  }

  HAL_NVIC_SetPriority(LPTIM1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(LPTIM1_IRQn);
}

void LPTIM_Start(void)
{
  /* Enable LPTIM TRIG */
  __HAL_LPTIM_ENABLE(&LPTIM_Handle);

  /* Enable interrupt */
  __HAL_LPTIM_ENABLE_IT(&LPTIM_Handle, LPTIM_IT_UPDATE);

  /*  Enable the LPTIM signal output on the corresponding pin */
  __HAL_LPTIM_CAPTURE_COMPARE_ENABLE(&LPTIM_Handle, LPTIM_CHANNEL_1);

  /* Start the LPTIM peripheral in Continuous mode*/
  __HAL_LPTIM_START_CONTINUOUS(&LPTIM_Handle);
}

void HAL_LPTIM_UpdateEventCallback(LPTIM_HandleTypeDef *hlptim)
{
	/* Sample data */
	HAL_ADC_Start(&ADCHandle);

	/* Check that data conversion ended */
	while(HAL_ADC_PollForConversion(&ADCHandle, 50));

	/* Stop the conversion */
	HAL_ADC_Stop(&ADCHandle);

	/* Store the data into a buffer */
	if(dataPoint < ADC_BUFFER_CHECK_SIZE)
		adc_data[dataPoint++] = HAL_ADC_GetValue(&ADCHandle);

	/* Reconfigure LPTIM frequency to trigger ADC with lower freq. */
	if(dataPoint == 256){
		__HAL_LPTIM_AUTORELOAD_SET(&LPTIM_Handle, LPTIM_ARR);
		__HAL_LPTIM_COMPARE_SET(&LPTIM_Handle,LPTIM_CHANNEL_1,LPTIM_CMP);
		state = ENTER;

	/* Stop the timer and stay awake */
	} else if (dataPoint > 320) {
		__HAL_LPTIM_CAPTURE_COMPARE_DISABLE(&LPTIM_Handle, LPTIM_CHANNEL_1);
		__HAL_LPTIM_DISABLE_IT(&LPTIM_Handle, LPTIM_IT_UPDATE);
		__HAL_LPTIM_DISABLE(&LPTIM_Handle);
		state = EXIT;

	} else {
		state = ENTER;
	}
}


#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}

#endif

void BSP_PB_Callback(Button_TypeDef Button)
{
  if(Button == BUTTON_USER)
  {
    UserButtonStatus = 1;
  }
}

void Error_Handler(void)
{
  while(1){}
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

