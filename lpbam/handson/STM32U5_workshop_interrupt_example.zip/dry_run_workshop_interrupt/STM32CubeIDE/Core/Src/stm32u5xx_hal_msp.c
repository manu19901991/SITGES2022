/**
  ******************************************************************************
  * @file    stm32u5xx_hal_msp.c
  * @author  MCD Application Team
  * @brief   HAL MSP module.
  *          This file template is located in the HAL folder and should be copied
  *          to the user folder.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32u5xx_hal.h"
#include "main.h"
/** @addtogroup STM32U5xx_HAL_Driver
  * @{
  */

/** @defgroup HAL_MSP HAL MSP module driver
  * @brief HAL MSP module.
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
DMA_DataHandlingConfTypeDef DataHandlingConfig;

/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/** @defgroup HAL_MSP_Private_Functions
  * @{
  */

/**
  * @brief  Initialize the Global MSP.
  * @retval None
  */
void HAL_MspInit(void)
{
  /* Enable LP DMA1 in Autonomous mode  */
  __HAL_RCC_LPDMA1_CLKAM_ENABLE();
  /* Enable SRAM4 in Autonomous mode  */
  __HAL_RCC_SRAM4_CLKAM_ENABLE();
  /* Enable ADC4 in Autonomous mode  */
  __HAL_RCC_ADC4_CLKAM_ENABLE();
 /* Enable LP timer in Autonomous mode  */
  __HAL_RCC_LPTIM1_CLKAM_ENABLE();
}

/**
  * @brief  Initialize the ADC MSP.
  * @param hadc ADC handle
  * @retval None
  */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
  RCC_PeriphCLKInitTypeDef  RCC_PeriphCLKInitStruct;
  GPIO_InitTypeDef          GPIO_InitStruct;

   /* Enable ADC GPIAO Clock */
  __HAL_RCC_GPIOB_CLK_ENABLE();

   /* Configure PB0 ADC4 */
  GPIO_InitStruct.Pin = ADC_PIN;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(ADC_PORT, &GPIO_InitStruct);

   /* Set MSIK as ADC Clock  */
  RCC_PeriphCLKInitStruct.PeriphClockSelection = RCC_PERIPHCLK_ADCDAC;
  RCC_PeriphCLKInitStruct.AdcDacClockSelection = RCC_ADCDACCLKSOURCE_MSIK;
  HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphCLKInitStruct);
}


/**
  * @brief  DeInitialize the Global MSP.
  * @retval None
  */
void HAL_MspDeInit(void)
{
  /* NOTE : This function is generated automatically by STM32CubeMX and eventually
            modified by the user
   */
}

/**
  * @brief  Initialize the PPP MSP.
  * @retval None
  */
/*
void HAL_PPP_MspInit(void)
{
}
*/

/**
  * @brief  DeInitialize the PPP MSP.
  * @retval None
  */
/*
void HAL_PPP_MspDeInit(void)
{
}
*/

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
