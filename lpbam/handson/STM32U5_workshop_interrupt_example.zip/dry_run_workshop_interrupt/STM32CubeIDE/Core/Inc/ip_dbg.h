/**
  ******************************************************************************
  * @file    stm32u5xx_ip_dbg.h
  * @author  MCD Application Team
  * @brief   Header for stm32u5xx_ip_dbg.c file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2018 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __stm32u5XX_IP_DBG_H
#define __stm32u5XX_IP_DBG_H

/* Includes ------------------------------------------------------------------*/
#include "stm32u5xx.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */

void IP_Debug(void);

#endif /* __stm32u5XX_IP_DBG_H */

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
