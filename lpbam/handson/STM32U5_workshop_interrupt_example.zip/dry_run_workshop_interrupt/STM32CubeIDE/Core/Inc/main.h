/**
  ******************************************************************************
  * @file    Templates/TrustZoneDisabled/Inc/main.h
  * @author  MCD Application Team
  * @brief   Header for main.c module
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef MAIN_H
#define MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32u5xx_hal.h"
#include "stm32u5xx_nucleo.h"
#include "stm32u5xx_ll_lptim.h"
#include "ip_dbg.h"

/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
/* adc defines */

#ifndef ADC_INSTANCE
#define ADC_INSTANCE ADC4
#endif
#ifndef ADC_PORT
#define ADC_PORT GPIOB
#endif
#ifndef TRIG_ADC_PORT
#define TRIG_ADC_PORT GPIOB
#endif
#ifndef ADC_PIN
#define ADC_PIN GPIO_PIN_0
#endif
#ifndef TRIG_ADC_PIN
#define GPIO GPIO_PIN_1
#endif
#define ADC_RANGE           4096         // ADC Range 2^NumberOfBits (2^12)  0xFFF
#define ADC_INPUT           ADC_RANGE    
                                                          
#define ADC_MIN (ADC_INPUT-(ADC_INPUT/10))
#define ADC_MAX (ADC_INPUT+(ADC_INPUT/10)) 

#define ADC_DATA_SIZE 320
#define ADC_BUFFER_SIZE ADC_DATA_SIZE

#define ADC_DATA_CAPTURE_SIZE_BUFF1 256
#define ADC_BUFFER_SIZE_256 ADC_DATA_CAPTURE_SIZE_BUFF1

#define ADC_DATA_CAPTURE_SIZE_BUFF2 64
#define ADC_BUFFER_SIZE_64 ADC_DATA_CAPTURE_SIZE_BUFF2

#define ADC_DATA_CHECK_SIZE 512
#define ADC_BUFFER_CHECK_SIZE ADC_DATA_CHECK_SIZE
                                                         
                                                         
#define ADC_CHANNEL    LL_ADC_CHANNEL_0
#define LPTIM_TRIG_ADC LPTIM1

#define LPTIM_REG_SIZE    4

void DMA_IRQHandler(void);
void Error_Handler(void);


/* @brief  Enable PWD .*/
#define __ADC_EnableDeepPowerDown(__HANDLE__)    ((__HANDLE__)->Instance->PW  |= (ADC4_PW_DPD))

#define ADC_SAMPLING LL_ADC4_SAMPLINGTIME_19CYCLES_5

#define Period_256HZ              0x80    //128

#endif /* MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
